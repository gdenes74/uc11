# leiloes
Nome do projeto> Leilões

Objetivo do Projeto>
Criar um sistema informatizado (repositório) em suas rotinas. Como parte das práticas de segurança e de qualidade de software, a empresa 
exige que o projeto esteja devidamente versionado utilizando o GitHub. 
Sua missão é criar um repositório para o projeto cuja implementação já foi iniciada.
Obs: os 3 últimos commits forão feitos, para definir a tela de cadastro do produto, no repositório local, bem como a tela de listagem de Produtos e o relatório da atividade 2, visando evidenciar a prática do envio para o repositório remoto do gitHub fazendo mais de 1 commit, utilizando o netbens e o MySql. Estou fazendo uma alteração no Readme para fazer um exercício de pull request, o caminho inverso, sendo feito primeiramente o commit changes. 
Tecnologias Utilizadas>
Java, MySql, GitBash e GitHub(remoto).
